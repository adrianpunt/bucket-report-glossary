# Bucket Reports Static Site Generation 

Using Vuepress to create the Bucket Reports glossary. Adrian you should:

- Clone this repo
- Edit `docs\Readme.md`
- Learn more about the Markdown format for tables https://www.markdownguide.org/extended-syntax/#tables

